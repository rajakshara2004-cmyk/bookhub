import React from 'react';
import ReactDOM from 'react-dom/client';
import './index_24BCE0020_L1_AKSHARA.css';
import App from './App_24BCE0020_L1_AKSHARA';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
