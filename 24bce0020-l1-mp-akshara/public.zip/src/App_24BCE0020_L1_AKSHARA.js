import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/components/Navbar_24BCE0020_L1_AKSHARA';
import Home from './pages/Home_24BCE0020_L1_AKSHARA';
import Sell from './pages/Sell_24BCE0020_L1_AKSHARA';
import Buy from './pages/Buy_24BCE0020_L1_AKSHARA';
import Rent from './pages/Rent_24BCE0020_L1_AKSHARA';
import Portfolio from './pages/Portfolio_24BCE0020_L1_AKSHARA';

const AKSHARARAJ_24BCE0020_App = () => {
  const [bookListings_24BCE0020, setBookListings_24BCE0020] = useState([]);

  const addBook_24BCE0020 = (newBook) => {
    setBookListings_24BCE0020(prev => [newBook, ...prev]);
  };

  return (
    <Router>
      <Navbar />
      <div className="page-wrapper">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/sell" element={<Sell addBook_24BCE0020={addBook_24BCE0020} bookListings_24BCE0020={bookListings_24BCE0020} />} />
          <Route path="/buy" element={<Buy bookListings_24BCE0020={bookListings_24BCE0020} />} />
          <Route path="/rent" element={<Rent bookListings_24BCE0020={bookListings_24BCE0020} />} />
          <Route path="/portfolio" element={<Portfolio />} />
        </Routes>
      </div>
    </Router>
  );
};

export default AKSHARARAJ_24BCE0020_App;